from time import process_time

from menu import Menu
from coffee_maker import CoffeeMaker
from money_machine import MoneyMachine



menu = Menu()
coffee_maker = CoffeeMaker()
money_machine = MoneyMachine()


#power on and print coffee
#print report
#print off

is_on = True
while is_on:
    print(menu.get_items())
    coffee = input("Enter chosen coffee: ")
    if coffee.lower() == 'off':
        is_on = False
    elif coffee.lower() == 'report':
        print(coffee_maker.report())
    else:
        if coffee_maker.is_resource_sufficient(menu.find_drink(coffee)):
            print("Sufficient")
            if money_machine.make_payment(menu.find_drink(coffee).cost):
                for x in coffee_maker.resources.keys():
                    if x in menu.find_drink(coffee).ingredients:
                        coffee_maker.resources[x] = coffee_maker.resources[x] - menu.find_drink(coffee).ingredients[x]
                print(coffee_maker.report())
                print(money_machine.report())

        else:
            print("Insufficient")




